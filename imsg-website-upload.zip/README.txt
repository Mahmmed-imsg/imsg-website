IMSG One-Page Site
===================
Files:
- index.html
- assets/logo.png
- assets/favicon.png / favicon.ico
- assets/og-image.png

Quick Deploy (Crazy Domains):
1) Log in → Web Hosting → Manage → cPanel → File Manager.
2) Open public_html/, click Upload, and upload the CONTENTS of this zip (index.html + assets folder).
3) If an older index.php exists, right-click → rename to index-old.php.
4) Visit your domain. Enable SSL and force HTTPS in Domains → Force HTTPS Redirect.
5) Edit index.html to replace TODO:FIRM_NAME, TODO:EMAIL, TODO:PHONE, TODO:ADDRESS, TODO:ABN, TODO:LINKEDIN_URL.
